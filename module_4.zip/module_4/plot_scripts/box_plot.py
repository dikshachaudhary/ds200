import matplotlib
import matplotlib.pyplot as plt
import pandas as pd
matplotlib.use('TkAgg')
import numpy as np

data1=pd.read_csv("data/sub-division_rainfall_act_dep_1901-2015.csv")

subdivision=['BIHAR', 'CHHATTISGARH','COASTAL KARNATAKA','ARUNACHAL PRADESH','EAST MADHYA PRADESH']

index=np.arange(len(subdivision)+1)  



rainfall_subdivisions=data1[data1.SUBDIVISION.isin(subdivision)]

filter2=rainfall_subdivisions['Parameter']=='Actual'
rainfall_subdivision_actual=rainfall_subdivisions[filter2]

# plt.figure()

fig, ax=plt.subplots()
boxplot=rainfall_subdivision_actual.boxplot(column='ANNUAL', by='SUBDIVISION',rot=30,ax=ax)

ax.set_xlabel('Subdivision')
ax.set_ylabel('Rainfall (in mm)',)
ax.set_title('Annual Rainfall 1901-2015')
# ax.set_xticks(index+0.5)
plt.suptitle("")
fig.tight_layout()
# plt.show()

plt.savefig("boxplot.pdf",bbox_inches='tight')
