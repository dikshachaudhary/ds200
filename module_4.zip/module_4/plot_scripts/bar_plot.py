import matplotlib
import matplotlib.pyplot as plt
import pandas as pd
matplotlib.use('TkAgg')
import numpy as np
#Year-wise Value of India's Merchandise Exports and Imports including Contribution of Small and Medium Enterprises from 2014-15 to 2017-18 (From : Ministry of Commerce & Industry)

cols=['year','export','change','import','trade_balance']
data1=pd.read_csv("data/export.csv",names=cols)

year=data1.year.tolist()
export=data1.export.tolist()
year.pop(0)
export.pop(0)
export = map(float, export)


# print year
# print export


index=np.arange(len(year))  
width=0.35  

fig, ax=plt.subplots()
bars=ax.bar(index, export, width)


ax.set_xlabel('Year')
ax.set_ylabel('In USD billion',)
ax.set_title('India\'s Merchandise Exports 2014-15 to 2017-18')
ax.set_xticks(index)
ax.set_xticklabels(year)
ax.legend()


for bar in bars:
    height = bar.get_height()
    ax.annotate('{}'.format(height), xy=(bar.get_x(), height),xytext=(0, 3),textcoords="offset points")


fig.tight_layout()

# plt.show()
plt.savefig("barplot.pdf",bbox_inches='tight')