import matplotlib
import matplotlib.pyplot as plt
import pandas as pd
matplotlib.use('TkAgg')
import numpy as np

data1=pd.read_csv("data/sub-division_rainfall_act_dep_1901-2015.csv")
data=data1[data1.Parameter=='Actual']


year=[]
for i in range(1901,2016):
	year.append(i)

subdivision=['BIHAR', 'SUB HIMALAYAN WEST BENGAL & SIKKIM','COASTAL KARNATAKA','EAST RAJASTHAN','WEST UTTAR PRADESH']
colorr=['firebrick','g','b','yellow','skyblue']

alphas=[0.5,0.6,0.7,0.8,0.9]

fig, ax=plt.subplots()

ax.set_xlabel('Year')
ax.set_ylabel('Rainfall (in mm)',)
ax.set_title('Annual Rainfall 1901-2015')



for j,i in enumerate(subdivision):
	sub=data[data.SUBDIVISION==i]
	rain=sub.ANNUAL.tolist()
	rain = map(float, rain)
	scatter=ax.scatter(year, rain, c=colorr[j],label=i,alpha=alphas[j])

ax.legend()
fig.tight_layout()
# plt.show()

plt.savefig("scatterplot.pdf",bbox_inches='tight')

